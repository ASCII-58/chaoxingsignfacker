if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Params {
    username?: string;
    password?: string;
    LoginEnable?: boolean;
    UsernameTranslateY?: number;
    PasswordTranslateY?: number;
    UsernameScale?: number;
    PasswordScale?: number;
}
import promptAction from "@ohos:promptAction";
import router from "@ohos:router";
import { DatabaseManager } from "@normalized:N&&&entry/src/main/ets/utils/DataBase&";
import type { UserData } from "@normalized:N&&&entry/src/main/ets/utils/DataBase&";
import { ChaoxingUtils } from "@normalized:N&&&entry/src/main/ets/utils/utils&";
import { loginFunction } from "@normalized:N&&&entry/src/main/ets/utils/Login&";
import JSON from "@ohos:util.json";
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__LoginEnable = new ObservedPropertySimplePU(false, this, "LoginEnable");
        this.__UsernameTranslateY = new ObservedPropertySimplePU(45, this, "UsernameTranslateY");
        this.__PasswordTranslateY = new ObservedPropertySimplePU(45, this, "PasswordTranslateY");
        this.__UsernameScale = new ObservedPropertySimplePU(0.9, this, "UsernameScale");
        this.__PasswordScale = new ObservedPropertySimplePU(0.9, this, "PasswordScale");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.LoginEnable !== undefined) {
            this.LoginEnable = params.LoginEnable;
        }
        if (params.UsernameTranslateY !== undefined) {
            this.UsernameTranslateY = params.UsernameTranslateY;
        }
        if (params.PasswordTranslateY !== undefined) {
            this.PasswordTranslateY = params.PasswordTranslateY;
        }
        if (params.UsernameScale !== undefined) {
            this.UsernameScale = params.UsernameScale;
        }
        if (params.PasswordScale !== undefined) {
            this.PasswordScale = params.PasswordScale;
        }
    }
    updateStateVars(params: Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__LoginEnable.purgeDependencyOnElmtId(rmElmtId);
        this.__UsernameTranslateY.purgeDependencyOnElmtId(rmElmtId);
        this.__PasswordTranslateY.purgeDependencyOnElmtId(rmElmtId);
        this.__UsernameScale.purgeDependencyOnElmtId(rmElmtId);
        this.__PasswordScale.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__LoginEnable.aboutToBeDeleted();
        this.__UsernameTranslateY.aboutToBeDeleted();
        this.__PasswordTranslateY.aboutToBeDeleted();
        this.__UsernameScale.aboutToBeDeleted();
        this.__PasswordScale.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __LoginEnable: ObservedPropertySimplePU<boolean>;
    get LoginEnable() {
        return this.__LoginEnable.get();
    }
    set LoginEnable(newValue: boolean) {
        this.__LoginEnable.set(newValue);
    }
    private __UsernameTranslateY: ObservedPropertySimplePU<number>;
    get UsernameTranslateY() {
        return this.__UsernameTranslateY.get();
    }
    set UsernameTranslateY(newValue: number) {
        this.__UsernameTranslateY.set(newValue);
    }
    private __PasswordTranslateY: ObservedPropertySimplePU<number>;
    get PasswordTranslateY() {
        return this.__PasswordTranslateY.get();
    }
    set PasswordTranslateY(newValue: number) {
        this.__PasswordTranslateY.set(newValue);
    }
    private __UsernameScale: ObservedPropertySimplePU<number>;
    get UsernameScale() {
        return this.__UsernameScale.get();
    }
    set UsernameScale(newValue: number) {
        this.__UsernameScale.set(newValue);
    }
    private __PasswordScale: ObservedPropertySimplePU<number>;
    get PasswordScale() {
        return this.__PasswordScale.get();
    }
    set PasswordScale(newValue: number) {
        this.__PasswordScale.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(19:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('学习通账号\n登录');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(20:7)", "entry");
            Text.margin({ top: 10, bottom: 10 });
            Text.fontSize(40);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用户名');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(24:7)", "entry");
            Text.fontSize(26);
            Text.height(40);
            Text.width('90%');
            Text.textAlign(TextAlign.Start);
            Text.translate({ y: this.UsernameTranslateY });
            Text.scale({ x: this.UsernameScale, y: this.UsernameScale });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '', text: this.username });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(31:7)", "entry");
            TextInput.type(InputType.Number);
            TextInput.onChange((value: string) => {
                this.username = value;
                if (this.username)
                    Context.animateTo({
                        duration: 300,
                        curve: 'smooth'
                    }, () => {
                        this.UsernameTranslateY = 0;
                        this.UsernameScale = 1;
                    });
                if (this.username && this.password) {
                    this.LoginEnable = true;
                }
            });
            TextInput.onFocus(() => {
                Context.animateTo({
                    duration: 300,
                    curve: 'smooth'
                }, () => {
                    this.UsernameTranslateY = 0;
                    this.UsernameScale = 1;
                });
            });
            TextInput.onBlur(() => {
                if (!this.username) {
                    Context.animateTo({
                        duration: 300,
                        curve: 'smooth'
                    }, () => {
                        this.UsernameTranslateY = 45;
                        this.UsernameScale = 0.9;
                    });
                }
            });
            TextInput.placeholderFont({ size: 16 });
            TextInput.height(50);
            TextInput.width('90%');
            TextInput.backgroundColor(Color.Transparent);
            TextInput.border({
                // 设置边框
                width: {
                    // 分别设置四个方向的边框宽度
                    top: 0,
                    right: 0,
                    bottom: 2,
                    left: 0
                },
                color: {
                    // 设置边框颜色
                    top: Color.Transparent,
                    right: Color.Transparent,
                    bottom: Color.Blue,
                    left: Color.Transparent
                },
                style: BorderStyle.Solid // 边框样式
                ,
                radius: 0
            });
            TextInput.margin({ bottom: 20 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('密码');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(92:7)", "entry");
            Text.fontSize(26);
            Text.height(40);
            Text.width('90%');
            Text.textAlign(TextAlign.Start);
            Text.translate({ y: this.PasswordTranslateY });
            Text.scale({ x: this.PasswordScale, y: this.PasswordScale });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '', text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(99:7)", "entry");
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
                if (this.password)
                    Context.animateTo({
                        duration: 300,
                        curve: 'smooth'
                    }, () => {
                        this.PasswordTranslateY = 0;
                        this.PasswordScale = 1;
                    });
                if (this.username && this.password) {
                    this.LoginEnable = true;
                }
            });
            TextInput.onFocus(() => {
                Context.animateTo({
                    duration: 300,
                    curve: 'smooth'
                }, () => {
                    this.PasswordTranslateY = 0;
                    this.PasswordScale = 1;
                });
            });
            TextInput.onBlur(() => {
                if (!this.password) {
                    Context.animateTo({
                        duration: 300,
                        curve: 'smooth'
                    }, () => {
                        this.PasswordTranslateY = 45;
                        this.PasswordScale = 0.9;
                    });
                }
            });
            TextInput.placeholderFont({ size: 16 });
            TextInput.height(50);
            TextInput.width('90%');
            TextInput.backgroundColor(Color.Transparent);
            TextInput.border({
                // 设置边框
                width: {
                    // 分别设置四个方向的边框宽度
                    top: 0,
                    right: 0,
                    bottom: 2,
                    left: 0
                },
                color: {
                    // 设置边框颜色
                    top: Color.Transparent,
                    right: Color.Transparent,
                    bottom: Color.Blue,
                    left: Color.Transparent
                },
                style: BorderStyle.Solid // 边框样式
                ,
                radius: 0
            });
            TextInput.margin({ bottom: 40 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(160:7)", "entry");
            Button.enabled(this.LoginEnable);
            Button.width('60%');
            Button.height(50);
            Button.onClick(async () => {
                this.LoginEnable = false;
                const uname = ChaoxingUtils.encryptByAES(this.username);
                const pwd = ChaoxingUtils.encryptByAES(this.password);
                const result = await (loginFunction.LoginChaoXing(ChaoxingUtils.getLoginBody(uname, pwd)));
                if (result) {
                    const cookies = result;
                    const info = await loginFunction.getUserInfo(cookies);
                    try {
                        const dbManager = DatabaseManager.getInstance();
                        const userData: UserData = {
                            phone: this.username,
                            pwd: pwd,
                            name: info.uname,
                            pic: info.pic,
                            cookies: cookies,
                            fid: info.fid,
                            uid: info.uid
                        };
                        console.log('fuck' + JSON.stringify(userData));
                        await dbManager.insertUser(userData);
                        this.username = '';
                        this.password = '';
                        promptAction.showToast({ message: '登录成功', duration: 2000 });
                        router.replaceUrl({
                            url: 'pages/Index' // 跳转目标页面路径
                        });
                    }
                    catch (e) {
                        this.username = '';
                        this.password = '';
                        if (e instanceof Error) {
                            if (e.message.includes('主用户已登录')) {
                                promptAction.showToast({ message: '主用户已登录,请勿重复登录', duration: 2000 });
                            }
                            else {
                                promptAction.showToast({
                                    message: '添加失败，请重试' +
                                        (e.message.includes("手机号已存在，请使用其他手机号") ? ', 该账号已添加' : ''),
                                    duration: 2000
                                });
                            }
                            return;
                        }
                    }
                }
                else {
                    promptAction.showToast({
                        message: result,
                        duration: 1500,
                        bottom: '20%' // 弹窗距离屏幕底部的距离，可以是vp或百分比。可选参数。
                    });
                    this.username = '';
                    this.password = '';
                }
            });
            Button.margin({ bottom: 20 });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login";
    }
}
registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "com.xhub.chaoxingsignfacker", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
