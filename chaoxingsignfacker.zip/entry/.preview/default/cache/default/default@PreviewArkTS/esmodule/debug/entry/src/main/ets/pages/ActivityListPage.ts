export function initClassInfo(parent = null) {
}
(function () {
    if (typeof NavigationBuilderRegister === "function") {
        NavigationBuilderRegister("ActivityList", wrapBuilder(initClassInfo));
    }
})();
