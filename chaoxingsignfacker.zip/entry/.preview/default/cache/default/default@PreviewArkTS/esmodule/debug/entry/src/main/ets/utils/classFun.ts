import http from "@ohos:net.http";
import { ChaoxingUtils } from "@normalized:N&&&entry/src/main/ets/utils/utils&";
export class CourseAndActivity {
    static readonly URL_GET_COURSE_LIST = 'mooc1-api.chaoxing.com/mycourse/backclazzdata?view=json&rss=1';
    static readonly URL_GET_ACTIVITY_LIST = 'https://mobilelearn.chaoxing.com/v2/apis/active/student/activelist?fid=0&showNotStartedActive=0';
    static readonly UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0';
    /**
     * 获取课程列表，需要cookies
     * @param cookies
     * @returns
     */
    static async getClassList(cookies: string): Promise<returnJson> {
        const httpRequest = http.createHttp();
        try {
            const result = await httpRequest.request(CourseAndActivity.URL_GET_COURSE_LIST, {
                method: http.RequestMethod.GET,
                header: {
                    "Cookie": cookies,
                    "User-Agent": CourseAndActivity.UA
                }
            });
            const CourseListResponse = JSON.parse(result.result.toString()) as CourseListResponse;
            if (CourseListResponse.msg === "获取成功") {
                const courseList = CourseListResponse.channelList;
                const result: classInfoType[] = [];
                courseList.forEach(item => {
                    // 检查 content 和 course.data 是否存在
                    if (item.content && item.content.course && item.content.course.data) {
                        item.content.course.data.forEach(course => {
                            result.push({
                                imageurl: course.imageurl,
                                id: course.id,
                                teacherfactor: course.teacherfactor,
                                classId: item.content.id,
                                name: course.name
                            });
                        });
                    }
                });
                return { msg: true, classList: result };
            }
        }
        catch {
        }
        finally {
            httpRequest.destroy();
        }
        return {
            msg: false,
            classList: [
                {
                    imageurl: '',
                    id: 0,
                    teacherfactor: '',
                    classId: 0,
                    name: ''
                }
            ]
        };
    }
    static async getActivity(cookies: string, classId: number, courseId: number): Promise<ActivityItem[] | null> {
        const httpRequest = http.createHttp();
        try {
            const result = await httpRequest.request(ChaoxingUtils.buildUrl(CourseAndActivity.URL_GET_COURSE_LIST, {
                'classId': classId,
                'courseId': courseId
            }), {
                method: http.RequestMethod.GET,
                header: {
                    "Cookie": cookies,
                    "User-Agent": CourseAndActivity.UA
                }
            });
            const ActivityMessage = JSON.parse(result.result.toString()) as object;
            const ActivityList = ActivityMessage?.['data']?.['activeList'] as ActivityItem[];
            return ActivityList;
        }
        catch (error) {
            console.error('fuck+' + error);
            return null;
        }
        finally {
            httpRequest.destroy();
        }
    }
}
export interface ActivityItem {
    /** 签到类型ID，用于识别签到方式 */
    otherId: number;
    /** 活动类型，用于过滤显示（2=签到, 74=签退） */
    type: number;
    /** 签到类型名称，如"位置签到"、"二维码签到"等 */
    nameOne: string;
    /** 活动开始时间戳，用于判断签到是否开始和计算剩余时间 */
    startTime: number;
    /** 活动ID，用于页面导航参数传递 */
    id: number;
    /** 活动结束时间戳，用于判断签到是否结束和控制UI状态 */
    endTime: number;
}
export interface classInfoType {
    imageurl: string;
    id: number; // 课程id
    teacherfactor: string;
    classId: number; // 班级id
    name: string;
}
// 课程频道项目接口
export interface CourseChannel {
    /** 分类ID */
    cataid: string;
    /** 项目ID */
    id: number;
    /** 班级唯一标识符 */
    key: number | string;
    /** 课程内容详情 */
    content: CourseContent;
    /** 置顶标记 */
    topsign: number;
}
// 班级/课程内容接口
export interface CourseContent {
    /** 班级名称 */
    name: string;
    /** 课程数据 */
    course: Data;
    /** 班级ID */
    id: number;
}
// 课程基本信息接口
export interface CourseInfo {
    /** 课程ID */
    id: number;
    /** 课程名称 */
    name: string;
    /** 授课教师 */
    teacherfactor: string;
    /** 创建时间戳 */
    createtime: number;
    /** 课程图片URL */
    imageurl: string;
    /** 课程状态 */
    coursestate: number;
}
// 课程列表响应接口
export interface CourseListResponse {
    /** 响应结果：1=成功 */
    result: number;
    /** 响应消息 */
    msg: string;
    /** 课程频道列表 */
    channelList: CourseChannel[];
    /** 教师结课状态 */
    teacherEndCourse: number;
    /** 显示结课状态 */
    showEndCourse: number;
    /** 学生结课状态 */
    stuEndCourse: number;
}
export interface Data {
    data: CourseInfo[];
}
export interface returnJson {
    msg: boolean;
    classList: classInfoType[];
}
