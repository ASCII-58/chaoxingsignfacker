export function initSignInfo(parent = null) {
}
(function () {
    if (typeof NavigationBuilderRegister === "function") {
        NavigationBuilderRegister("SignerPage", wrapBuilder(initSignInfo));
    }
})();
