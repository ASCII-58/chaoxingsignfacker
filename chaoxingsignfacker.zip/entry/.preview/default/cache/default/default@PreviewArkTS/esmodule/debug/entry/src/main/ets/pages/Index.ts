if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface UI_Params {
    currentIndex?: number;
    HostImageData?: image.PixelMap | Resource;
    hostName?: Resource | string;
    hostPhone?: Resource | string;
    value?: string;
    titleName?: string;
    classList?: classInfoType[] | null;
    QRCode?: boolean;
    pathInfos?: NavPathStack;
    controller?: TabsController;
    uiContext?: UIContext;
    QRCodeDialogController?: CustomDialogController;
}
interface ClassIcon_Params {
    imageurl?: string;
    ImageData?: image.PixelMap | null;
}
interface QRCodeDialog_Params {
    controller?: CustomDialogController;
    value?: string;
}
import { DatabaseManager } from "@normalized:N&&&entry/src/main/ets/utils/DataBase&";
import { loginFunction } from "@normalized:N&&&entry/src/main/ets/utils/Login&";
import type image from "@ohos:multimedia.image";
import { CourseAndActivity } from "@normalized:N&&&entry/src/main/ets/utils/classFun&";
import type { classInfoType } from "@normalized:N&&&entry/src/main/ets/utils/classFun&";
class QRCodeDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.__value = new SynchedPropertySimpleOneWayPU(params.value, this, "value");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: QRCodeDialog_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params: QRCodeDialog_Params) {
        this.__value.reset(params.value);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private __value: SynchedPropertySimpleOneWayPU<string>;
    get value() {
        return this.__value.get();
    }
    set value(newValue: string) {
        this.__value.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(12:5)", "entry");
            Column.backgroundColor({ "id": 125829129, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Column.borderRadius(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.value) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(14:9)", "entry");
                        Column.margin(20);
                        Column.borderRadius(20);
                        Column.borderColor('#3388ff');
                        Column.borderWidth(3);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(15:11)", "entry");
                        Column.margin(10);
                        Column.width(260);
                        Column.height(260);
                        Column.backgroundColor({ "id": 125831026, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                        Column.borderRadius(10);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        QRCode.create(this.value);
                        QRCode.debugLine("entry/src/main/ets/pages/Index.ets(16:13)", "entry");
                        QRCode.width(240);
                        QRCode.height(240);
                        QRCode.margin({ top: 10 });
                    }, QRCode);
                    QRCode.pop();
                    Column.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(25:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('未读取到用户信息');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(26:11)", "entry");
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('关闭');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(29:7)", "entry");
            Button.onClick(() => {
                this.controller.close(); // 调用controller的close方法关闭弹窗
            });
            Button.margin({ bottom: 30 });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class ClassIcon extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__imageurl = new SynchedPropertySimpleOneWayPU(params.imageurl, this, "imageurl");
        this.__ImageData = new ObservedPropertyObjectPU(null, this, "ImageData");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClassIcon_Params) {
        if (params.ImageData !== undefined) {
            this.ImageData = params.ImageData;
        }
    }
    updateStateVars(params: ClassIcon_Params) {
        this.__imageurl.reset(params.imageurl);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__imageurl.purgeDependencyOnElmtId(rmElmtId);
        this.__ImageData.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__imageurl.aboutToBeDeleted();
        this.__ImageData.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    updateRecycleElmtId(oldElmtId, newElmtId) {
        this.__imageurl.updateElmtId(oldElmtId, newElmtId);
        this.__ImageData.updateElmtId(oldElmtId, newElmtId);
    }
    private __imageurl: SynchedPropertySimpleOneWayPU<string>;
    get imageurl() {
        return this.__imageurl.get();
    }
    set imageurl(newValue: string) {
        this.__imageurl.set(newValue);
    }
    private __ImageData: ObservedPropertyObjectPU<image.PixelMap | null>;
    get ImageData() {
        return this.__ImageData.get();
    }
    set ImageData(newValue: image.PixelMap | null) {
        this.__ImageData.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(45:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.ImageData);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(46:7)", "entry");
            Image.borderColor({ "id": 16777236, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            if (isInitialRender) {
                Image.width(50);
                Image.height(50);
                Image.borderWidth(3);
                Image.borderRadius(10);
                Image.margin(10);
                Image.onAppear(async () => {
                    this.ImageData = await loginFunction.GetPic(this.imageurl);
                });
            }
        }, Image);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class UI extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__HostImageData = new ObservedPropertyObjectPU({ "id": 16777216, "type": 20000, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" }, this, "HostImageData");
        this.__hostName = new ObservedPropertyObjectPU({ "id": 16777224, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" }, this, "hostName");
        this.__hostPhone = new ObservedPropertyObjectPU({ "id": 16777233, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" }, this, "hostPhone");
        this.__value = new ObservedPropertySimplePU('', this, "value");
        this.__titleName = new ObservedPropertySimplePU('首页', this, "titleName");
        this.__classList = new ObservedPropertyObjectPU(null, this, "classList");
        this.__QRCode = new ObservedPropertySimplePU(false, this, "QRCode");
        this.__pathInfos = new ObservedPropertyObjectPU(new NavPathStack(), this, "pathInfos");
        this.addProvidedVar("pathInfos", this.__pathInfos, false);
        this.controller = new TabsController();
        this.uiContext = this.getUIContext();
        this.QRCodeDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new QRCodeDialog(this, { value: this.value }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 76, col: 14 });
                jsDialog.setController(this.QRCodeDialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        value: this.value
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            alignment: DialogAlignment.Center,
            customStyle: true,
            cornerRadius: 10,
            width: 300,
            height: 300,
            backgroundColor: Color.White
        }, this);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: UI_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.HostImageData !== undefined) {
            this.HostImageData = params.HostImageData;
        }
        if (params.hostName !== undefined) {
            this.hostName = params.hostName;
        }
        if (params.hostPhone !== undefined) {
            this.hostPhone = params.hostPhone;
        }
        if (params.value !== undefined) {
            this.value = params.value;
        }
        if (params.titleName !== undefined) {
            this.titleName = params.titleName;
        }
        if (params.classList !== undefined) {
            this.classList = params.classList;
        }
        if (params.QRCode !== undefined) {
            this.QRCode = params.QRCode;
        }
        if (params.pathInfos !== undefined) {
            this.pathInfos = params.pathInfos;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.uiContext !== undefined) {
            this.uiContext = params.uiContext;
        }
        if (params.QRCodeDialogController !== undefined) {
            this.QRCodeDialogController = params.QRCodeDialogController;
        }
    }
    updateStateVars(params: UI_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__HostImageData.purgeDependencyOnElmtId(rmElmtId);
        this.__hostName.purgeDependencyOnElmtId(rmElmtId);
        this.__hostPhone.purgeDependencyOnElmtId(rmElmtId);
        this.__value.purgeDependencyOnElmtId(rmElmtId);
        this.__titleName.purgeDependencyOnElmtId(rmElmtId);
        this.__classList.purgeDependencyOnElmtId(rmElmtId);
        this.__QRCode.purgeDependencyOnElmtId(rmElmtId);
        this.__pathInfos.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__HostImageData.aboutToBeDeleted();
        this.__hostName.aboutToBeDeleted();
        this.__hostPhone.aboutToBeDeleted();
        this.__value.aboutToBeDeleted();
        this.__titleName.aboutToBeDeleted();
        this.__classList.aboutToBeDeleted();
        this.__QRCode.aboutToBeDeleted();
        this.__pathInfos.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private __HostImageData: ObservedPropertyObjectPU<image.PixelMap | Resource>; // 用于存储下载的图片二进制数据
    get HostImageData() {
        return this.__HostImageData.get();
    }
    set HostImageData(newValue: image.PixelMap | Resource) {
        this.__HostImageData.set(newValue);
    }
    private __hostName: ObservedPropertyObjectPU<Resource | string>;
    get hostName() {
        return this.__hostName.get();
    }
    set hostName(newValue: Resource | string) {
        this.__hostName.set(newValue);
    }
    private __hostPhone: ObservedPropertyObjectPU<Resource | string>;
    get hostPhone() {
        return this.__hostPhone.get();
    }
    set hostPhone(newValue: Resource | string) {
        this.__hostPhone.set(newValue);
    }
    private __value: ObservedPropertySimplePU<string>;
    get value() {
        return this.__value.get();
    }
    set value(newValue: string) {
        this.__value.set(newValue);
    }
    private __titleName: ObservedPropertySimplePU<string>;
    get titleName() {
        return this.__titleName.get();
    }
    set titleName(newValue: string) {
        this.__titleName.set(newValue);
    }
    private __classList: ObservedPropertyObjectPU<classInfoType[] | null>;
    get classList() {
        return this.__classList.get();
    }
    set classList(newValue: classInfoType[] | null) {
        this.__classList.set(newValue);
    }
    private __QRCode: ObservedPropertySimplePU<boolean>;
    get QRCode() {
        return this.__QRCode.get();
    }
    set QRCode(newValue: boolean) {
        this.__QRCode.set(newValue);
    }
    private __pathInfos: ObservedPropertyObjectPU<NavPathStack>;
    get pathInfos() {
        return this.__pathInfos.get();
    }
    set pathInfos(newValue: NavPathStack) {
        this.__pathInfos.set(newValue);
    }
    private controller: TabsController;
    private uiContext: UIContext;
    private QRCodeDialogController: CustomDialogController;
    tabBuilder(title: string, targetIndex: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(87:5)", "entry");
            Column.width('25%');
            Column.height(20);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(88:7)", "entry");
            Text.fontColor(this.currentIndex === targetIndex ? { "id": 125830986, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" } : { "id": 125830982, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Text.fontWeight(this.currentIndex === targetIndex ? FontWeight.Bold : FontWeight.Regular);
            Text.fontSize(this.currentIndex === targetIndex ? { "id": 125830973, "type": 10002, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" } : { "id": 125830974, "type": 10002, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Text.onClick(() => {
                Context.animateTo({
                    duration: 100,
                    curve: Curve.Ease
                }, () => {
                    this.currentIndex = targetIndex;
                    this.controller.changeIndex(targetIndex);
                });
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentIndex === targetIndex) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/Index.ets(103:9)", "entry");
                        Context.animation({
                            duration: 100,
                            curve: Curve.Ease,
                            delay: 0,
                            iterations: 1,
                            playMode: PlayMode.Normal
                        });
                        Divider.strokeWidth(2);
                        Divider.color({ "id": 125830995, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                        Divider.width(20);
                        Divider.margin({ top: 4 });
                        Divider.scale({ x: 1, y: 1 });
                        Context.animation(null);
                    }, Divider);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(124:5)", "entry");
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundImageSize({ width: '100%', height: '100%' });
            Column.borderRadius({ "id": 125830913, "type": 10002, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Column.height('100%');
            Column.width('100%');
            Column.onAppear(async () => {
                try {
                    const dbManager = DatabaseManager.getInstance();
                    const url = await dbManager.getUserInfoByPhone('id', 'HostUser', 1, 'pic') as string;
                    this.HostImageData = await loginFunction.GetPic(url) as image.PixelMap;
                    this.hostName = await dbManager.getUserInfoByPhone('id', 'HostUser', 1, 'name') as string;
                    this.hostPhone = await dbManager.getUserInfoByPhone('id', 'HostUser', 1, 'phone') as string;
                    this.value =
                        `http://cdn.aquamarine5.fun/?phone=${this.hostPhone}&pwd=${encodeURIComponent(await dbManager.getUserInfoByPhone('id', 'HostUser', 1, 'pwd') as string)}&name=${decodeURIComponent(this.hostName)}`;
                    if (this.hostName.toString() === { "id": 16777224, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" }.toString()) {
                        this.uiContext.getRouter().pushUrl({ url: 'pages/Login' });
                    }
                }
                catch (e) {
                    console.error('fuck' + e);
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Navigation.create(this.pathInfos, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/Index", isUserCreateStack: true });
            Navigation.debugLine("entry/src/main/ets/pages/Index.ets(125:7)", "entry");
            Navigation.mode(NavigationMode.Auto);
            Navigation.backgroundColor({ "id": 125831007, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Navigation.title(this.titleName);
        }, Navigation);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ controller: this.controller });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(126:9)", "entry");
            Tabs.barWidth('100%');
            Tabs.barHeight(35);
            Tabs.vertical(false);
            Tabs.barPosition(BarPosition.End);
            Tabs.backgroundBlurStyle(BlurStyle.COMPONENT_ULTRA_THIN);
            Tabs.fadingEdge(true);
            Tabs.barMode(BarMode.Fixed);
            Tabs.animationDuration(0);
            Tabs.backgroundColor({ "id": 125831007, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            Tabs.divider({ strokeWidth: '1px', color: { "id": 125831013, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" } });
            Tabs.scrollable(false);
            Tabs.onChange((index) => {
                this.titleName = index === 0 ? '首页' : '用户中心';
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(129:13)", "entry");
                    Column.height('100%');
                    Column.width('100%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    List.create({ space: 12, initialIndex: 0 });
                    List.debugLine("entry/src/main/ets/pages/Index.ets(130:15)", "entry");
                    List.height('100%');
                    List.width('100%');
                }, List);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const classInfo = _item;
                        {
                            const itemCreation = (elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                ListItem.create(deepRenderFunction, true);
                                if (!isInitialRender) {
                                    ListItem.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            };
                            const itemCreation2 = (elmtId, isInitialRender) => {
                                ListItem.create(deepRenderFunction, true);
                                ListItem.width('100%');
                                ListItem.backgroundColor({ "id": 16777234, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                                ListItem.height(70);
                                ListItem.borderRadius(20);
                                ListItem.onClick(() => {
                                    this.pathInfos.pushPath({ name: 'ActivityList', param: classInfo });
                                });
                                ListItem.debugLine("entry/src/main/ets/pages/Index.ets(132:19)", "entry");
                            };
                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                itemCreation(elmtId, isInitialRender);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/Index.ets(133:21)", "entry");
                                    Row.width('100%');
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    __Recycle__.create();
                                }, __Recycle__);
                                {
                                    this.observeRecycleComponentCreation("ClassIcon", (elmtId, isInitialRender, recycleNode = null) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        if (isInitialRender) {
                                            let componentCall = recycleNode ? recycleNode : new ClassIcon(this, { imageurl: classInfo.imageurl }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 134, col: 23 });
                                            ViewPU.createRecycle(componentCall, recycleNode !== null, "ClassIcon", () => {
                                                if (recycleNode && typeof recycleNode.aboutToReuseInternal === "function") {
                                                    recycleNode.aboutToReuseInternal();
                                                }
                                                else {
                                                    if (recycleNode.aboutToReuse && typeof recycleNode.aboutToReuse === "function") {
                                                        recycleNode.aboutToReuse({ imageurl: classInfo.imageurl });
                                                    }
                                                    recycleNode.rerender();
                                                }
                                            });
                                            let paramsLambda = () => {
                                                return {
                                                    imageurl: classInfo.imageurl
                                                };
                                            };
                                            componentCall.paramsGenerator_ = paramsLambda;
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                                imageurl: classInfo.imageurl
                                            });
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                }
                                __Recycle__.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/Index.ets(135:23)", "entry");
                                    Column.width(200);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(classInfo.name);
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(136:25)", "entry");
                                    Text.fontSize(15);
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(classInfo.teacherfactor);
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(137:25)", "entry");
                                    Text.fontSize(10);
                                    Text.textAlign(TextAlign.Start);
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                                Column.pop();
                                Row.pop();
                                ListItem.pop();
                            };
                            this.observeComponentCreation2(itemCreation2, ListItem);
                            ListItem.pop();
                        }
                    };
                    this.forEachUpdateFunction(elmtId, this.classList, forEachItemGenFunction);
                }, ForEach);
                ForEach.pop();
                List.pop();
                Column.pop();
            });
            TabContent.tabBar({ "id": 16777223, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            TabContent.onAppear(async () => {
                // 加载课程列表
                const dbManager = DatabaseManager.getInstance();
                const cookies = await dbManager.getUserInfoByPhone('id', 'HostUser', 1, 'cookies') as string;
                console.log('fuck' + cookies);
                this.classList = (await CourseAndActivity.getClassList(cookies)).classList;
                this.classList.forEach(element => {
                    console.log('fuck' + JSON.stringify(element));
                });
            });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(128:11)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(168:13)", "entry");
                    Column.height('100%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(169:15)", "entry");
                    Column.width('100%');
                    Column.justifyContent(FlexAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(170:17)", "entry");
                    Row.width('97%');
                    Row.height(70);
                    Row.backgroundColor({ "id": 16777237, "type": 10001, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                    Row.borderRadius({
                        topLeft: 15,
                        bottomLeft: 15,
                        bottomRight: 35,
                        topRight: 35
                    });
                    Row.padding({ left: 5, right: 5 });
                    Row.zIndex(999999);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(this.HostImageData);
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(171:19)", "entry");
                    Image.width(50);
                    Image.height(50);
                    Image.borderRadius(10);
                    Image.objectFit(ImageFit.Cover);
                    Image.alt({ "id": 16777216, "type": 20000, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                    Image.margin({ left: 7.5 });
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(179:19)", "entry");
                    Column.margin({ left: 10 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.hostName);
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(180:21)", "entry");
                    Text.fontSize(20);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.hostPhone);
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(183:21)", "entry");
                    Text.fontSize(10);
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/Index.ets(188:19)", "entry");
                    Blank.layoutWeight(1);
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('退出', { buttonStyle: ButtonStyleMode.NORMAL, role: ButtonRole.ERROR });
                    Button.debugLine("entry/src/main/ets/pages/Index.ets(189:19)", "entry");
                    Button.fontSize(20);
                    Button.onClick(async () => {
                        const dbManager = DatabaseManager.getInstance();
                        try {
                            await dbManager.clearHostUserTable();
                        }
                        catch (error) {
                            console.error('fuck');
                        }
                        this.hostName = { "id": 16777224, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" };
                        this.hostPhone = { "id": 16777233, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" };
                        this.HostImageData = { "id": 16777216, "type": 20000, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" };
                        this.uiContext.getRouter().replaceUrl({ url: 'pages/LoginPage' });
                    });
                    Button.margin({ right: 15 });
                    Button.height(40);
                    Button.borderRadius(20);
                }, Button);
                Button.pop();
                Row.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(222:15)", "entry");
                    Row.onClick(() => {
                        this.QRCodeDialogController.open();
                    });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithChild();
                    Button.debugLine("entry/src/main/ets/pages/Index.ets(223:17)", "entry");
                }, Button);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(224:19)", "entry");
                    Column.height(70);
                    Column.width(70);
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 125830095, "type": 20000, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(225:21)", "entry");
                    Image.height(40);
                    Image.width(40);
                }, Image);
                Column.pop();
                Button.pop();
                Row.pop();
                Column.pop();
            });
            TabContent.tabBar({ "id": 16777227, "type": 10003, params: [], "bundleName": "com.xhub.chaoxingsignfacker", "moduleName": "entry" });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(167:11)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
        Navigation.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "UI";
    }
}
registerNamedRoute(() => new UI(undefined, {}), "", { bundleName: "com.xhub.chaoxingsignfacker", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
