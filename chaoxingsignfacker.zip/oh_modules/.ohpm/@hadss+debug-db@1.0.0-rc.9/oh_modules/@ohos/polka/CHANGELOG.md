## v1.0.3
## docs
1. doc changes

## v1.0.2
## chore
1. fix repository from gitee to gitcode in oh-packaage.json5. 

## v1.0.1
## fixes
1. Clean up potential buffer objects and close the close service.

## v1.0.0
## fixes
1. There is a memory leak and the repair buffer cannot be released.
2. Modify repository address.
3. Modify the LICENSE link in the README document.

## v1.0.0-rc.3
## fixes
1. The POST or PUT request is responded twice.

## v1.0.0-rc.2
## fixes
1. Multiple requests sent by the browser are received at the same time.

## v1.0.0-rc.1
## fixes
1. The static server cannot load the front-end packed HTML file.

## v1.0.0-rc.0

1. Adapts to polka, implements local HTTP encoding and decoding, and provides the static file server function.