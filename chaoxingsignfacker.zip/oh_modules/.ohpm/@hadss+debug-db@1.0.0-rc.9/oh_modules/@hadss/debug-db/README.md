# HarmonyOS Debug Database (debug-db)

一款功能强大的鸿蒙应用数据库可视化调试工具，开发者可通过浏览器来查看和操作多种 HarmonyOS 数据库，大幅提升数据库调试效率。

支持关系型数据库 (RdbStore)、用户首选项 (Preferences)、键值数据库 (KVStore)、AppStorage。

## 可视化界面
![](https://agc-storage-drcn.platform.dbankcloud.cn/v0/system-default-461323198429321829/lowcode/materials/debug-db%2F49cd5737f6a848e4a8f430be99ee0c69.png)

## 功能特性

**以下所有的功能都可以在不需要对设备进行 Root 操作（无需Root设备）的情况下使用：**
### RdbStore
- 查看指定UIAbilityContext以及ApplicationContext（APP__前缀）的所有RdbStore 数据库 (包括**加密**数据库)
- 支持自定义路径，递归扫描对应context下的rdb目录
- 查看指定 RdbStore 数据库中的所有表
- 查看 RdbStore 数据库中指定表的所有数据
- 在指定的 RdbStore 数据库上运行任何SQL查询来创建、删除数据库，或增删改查数据库数据
- 直接对 RdbStore 数据进行增删改查
- 下载指定 RdbStore 对应的数据库文件

### KVStore
- 查看指定UIAbilityContext以及ApplicationContext下所有的 KVStore (包括**加密**KV数据库)，storeId要唯一
- 查看指定 KVStore 中所有键值对数据
- 直接对 KVStore 数据进行增删改查

### Preferences
- 查看指定UIAbilityContext以及ApplicationContext（APP__前缀）下所有的 Preferences
- 查看指定 Preferences中所有首选项数据
- 直接对 Preferences 数据进行增删改查

### AppStorage
- 直接对 AppStorage 进行增删改查

## 使用说明

### 下载安装

```
ohpm install @hadss/debug-db
```

或 添加依赖配置，然后同步
```
// oh-package.json5
{
  "dependencies": {
    "@hadss/debug-db": "^1.0.0-rc.9"
  }
}
```

### 基础用法

```
// EntryAbility.ets

// 导入BuildProfile，编译期自动生成
import BuildProfile from 'BuildProfile';

onWindowStageCreate(windowStage: window.WindowStage): void {
  // Main window is created, set main page for this ability
  hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');

  windowStage.loadContent('pages/Index', (err) => {
    if (err.code) {
      ...
      return;
    }
    
    // 推荐在 DEBUG 模式下使用 - 动态加载。
    if (BuildProfile.DEBUG) {
      import('@hadss/debug-db').then(async (ns: ESObject) => {
        await ns.DebugDB.initialize(this.context, { port: 8080, defaultStart: true });
      });
    }
  });
}
```
当开发者启动应用程序后，应用后台会自动启动 DebugDB 服务，若成功启动，则可以在 DevEco Studio 的 Log 界面查看到以下日志：

```
You can access DebugDB through http://xxx.xxx.xxx.xxx:8080/index.html
```

日志中的网址即为 DebugDB 运行时的界面首页，直接在浏览器中访问即可。

### 高级用法：只在debug包中集成debug-db，打release包时去掉相关代码和配置

详情请参考demo工程：[debug-database](https://gitee.com/ohadss/debug-database)

### 模拟器使用
1、debug-db服务开启后，模拟器需转发端口，才能访问。（以8080端口为例）
```
# 查看模拟器设备
> hdc list targets   # 输出: 127.0.0.1:5555

# 转发端口 fport tcp:<localPort> tcp:<serverPort>
hdc -t 127.0.0.1:5555 fport tcp:8080 tcp:8080

# 输出: Forwardport result:OK 表示成功
```
转发成功后，访问： http://127.0.0.1:8080/index.html , 如果无法访问，请排查下是否有开启网络代理工具，建议关闭后再试试看。

2、也可直接使用模拟器自带的浏览器来访问，建议选择屏幕大点的设备（例如：折叠机或平板）体验更好。

### 注意事项
- URL地址详细说明（以8080端口为例），请按需选择。
  - 场景1：真机和PC连接同一个wifi，地址为：http://xxx.xxx.xxx.xxx:8080/index.html, 查看IDE日志或者直接查看真机设备IP：设置 -> WLAN -> 已连接的WIFI详情 -> IP地址
  - 场景2：真机开热点，PC连真机热点，地址为：http://192.168.43.1:8080/index.html
  - 场景3：直接设备自带浏览器，或者模拟器转发端口，地址为：http://127.0.0.1:8080/index.html
- DebugDB.initialize方法默认会启动server，可以设置defaultStart=false默认不启动server，需要时再调用start方法启动。
- 为了避免在正式发布版本中使用调试能力，debug-db会强制只有应用处于调试模式或者签名证书是debug类型（[ApplicationInfo](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-bundlemanager-applicationinfo#applicationinfo-1).debug || ApplicationInfo.appProvisionType === 'debug'），才会启动服务
- DebugDB stop后再start可能出现生效慢（demo实测要10-60s）或者不稳定的情况，请耐心等待一会儿。或者直接重启应用，首次start实测未发现问题。

## 其他说明

**实现说明**

本项目采用开源库 [polka](https://ohpm.openharmony.cn/#/cn/detail/@ohos%2Fpolka)实现http服务，UI界面基于 [Android-Debug-Database](https://github.com/amitshekhariitbhu/Android-Debug-Database?tab=readme-ov-file) 修改。

**相关权限**

由于需要通过浏览器直接访问服务端获取数据库信息，因此 debug-db 使用了以下权限：

```
  "requestPermissions": [{
    "name": "ohos.permission.GET_WIFI_INFO"
  },{
    "name": "ohos.permission.INTERNET"
  }],
```

**约束与限制**

在下述版本通过验证：
- DevEco Studio 5.0.1 Release (5.0.5.306)
- API 12 Release

**觉得这个项目有用吗？❤️**

- 点击此页面右上角的⭐按钮来支持本项目。✌️

本项目当前为 RC 版本，我们后续将会开发更多的功能并对错误进行修复，使用过程中发现的任何问题都可以提issue给我们，欢迎你的反馈。

**开源协议**

本项目基于[Apache License 2.0](https://gitee.com/openharmony-tpc/ImageKnife/blob/master/LICENSE)，请自由地享受与参与开源。🌏
