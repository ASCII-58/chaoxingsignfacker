## [1.0.0-rc.9] 2025.09.18
* 完善web页面加载失败场景的报错日志和response内容

## [1.0.0-rc.8] 2025.09.05
* fix：移除废弃API getContext()，改从入参获取context

## [1.0.0-rc.7] 2025.07.21
* fix bug：将rawfile下的资源统一放到debug_db目录下，和应用的其它资源区分开，避免冲突。
* release版本运行时默认不支持该能力，避免应用将调试功能带到release版本。
* 更新依赖@ohos/polka到1.0.3版本。

## [1.0.0-rc.6] 2025.01.07
* 更新readme，补充模拟器场景使用debug-db的指导，补充手机开热点场景的IP地址信息。
* 完善getDebugDBAddress方法，连wifi返回wifi地址，否则返回127.0.0.1。

## [1.0.0-rc.5] 2024.12.10
* 支持AppStorage可视化增删改查
* 支持初始化时设置默认启动或者关闭

## [1.0.0-rc.4] 2024.11.26
* 修复ApplicationContext下db文件下载失败的bug

## [1.0.0-rc.3] 2024.11.19
* 支持查看指定UIAbilityContext以及ApplicationContext下的数据库
* 支持查看自定义路径的rdb数据库，递归扫描对应context下的rdb目录

## [1.0.0-rc.2] 2024.11.11
* 修正了README中关于安装debug-db的示例说明

## [1.0.0-rc.1] 2024.10.21
* 新增查看加密rdb数据库和加密KV数据库功能
* 新增刷新当前表数据功能

## [1.0.0-rc.0] 2024.9.23
* 发布1.0.0-rc.0初始版本